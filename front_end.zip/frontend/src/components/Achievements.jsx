import React from 'react';
import './index.css'; // Optional for styling

const achievements = [
  { title: "Saved $1,000", date: "January 2024" },
  { title: "Paid Off Credit Card", date: "March 2024" },
  { title: "Completed Budget for 6 Months", date: "June 2024" },
];

const Achievements = () => (
  <div className="achievements">
    <h2 className="page-title">Achievements</h2>
    <ul className="achievements-list">
      {achievements.map((achievement, index) => (
        <li key={index} className="achievement-item">
          <span className="achievement-title">{achievement.title}</span>
          <span className="achievement-date">{achievement.date}</span>
        </li>
      ))}
    </ul>
  </div>
);

export default Achievements;