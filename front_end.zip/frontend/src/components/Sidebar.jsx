import React from 'react';
import { DollarSign, Home, Wallet, PieChart, Target, CreditCard, Briefcase, Award, Settings, MessageCircle } from 'lucide-react'; // Ensure you have the correct icons
import './index.css'; // Make sure to import the CSS for styling

const Sidebar = ({ activeNavItem, setActiveNavItem }) => {
  const navItems = [
    { icon: Home, label: "Dashboard" },
    { icon: Wallet, label: "Transactions" },
    { icon: PieChart, label: "Budgets" },
    { icon: Target, label: "Goals" },
    { icon: CreditCard, label: "Debt Management" },
    { icon: Briefcase, label: "Investments" },
    { icon: Award, label: "Achievements" },
    { icon: Settings, label: "Settings" },
    { icon: MessageCircle, label: "ChatBot" }, // Added Chatbot option
  ];

  return (
    <aside className="sidebar">
      <div className="logo">
        <DollarSign className="logo-icon" />
        <span className="logo-text">FinAI Assistant</span>
      </div>
      <nav className="nav">
        {navItems.map(({ icon: Icon, label }) => (
          <button
            key={label}
            className={`nav-item ${activeNavItem === label ? 'active' : ''}`}
            onClick={() => setActiveNavItem(label)}
          >
            <Icon className="nav-icon" />
            {label}
          </button>
        ))}
      </nav>
    </aside>
  );
};

export default Sidebar;
