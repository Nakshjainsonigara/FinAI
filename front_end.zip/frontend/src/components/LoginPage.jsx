// src/components/Login.js
import { useAuth } from "./AuthProvider";
import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom"; // Import Link and useNavigate
import "./index.css";

const Login = () => {
  const { login } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate(); // Hook for navigation

  const handleSubmit = (e) => {
    e.preventDefault();
    // You can implement authentication logic here, like calling an API
    console.log("Email:", email);
    console.log("Password:", password);
    alert("Login Successful!");
    
    // Navigate to the dashboard after successful login
    navigate("/"); // Assuming the dashboard is at the root path
  };

  return (
    <div className="login-container">
      <h2>Login to Your Financial Assistant</h2>
      <form onSubmit={handleSubmit} className="login-form">
        <div className="form-group">
          <label>Email:</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Enter your email"
            required
          />
        </div>
        <div className="form-group">
          <label>Password:</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Enter your password"
            required
          />
        </div>
        <button type="submit" className="login-btn">
          Login
        </button>
      </form>

      {/* New User? Sign Up section */}
      <div className="signup-prompt">
        <p>New User?</p>
        <Link to="/signup" className="signup-link">
          Sign Up
        </Link>
      </div>
    </div>
  );
};

export default Login;
