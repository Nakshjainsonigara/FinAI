import React from 'react';
import './index.css'; // Optional for styling

const investments = [
  { type: "Stocks", value: "$5,000", growth: "+10%" },
  { type: "Bonds", value: "$3,000", growth: "+5%" },
  { type: "Real Estate", value: "$20,000", growth: "+15%" },
];

const Investments = () => (
  <div className="investments">
    <h2 className="page-title">Investments</h2>
    <table className="investments-table">
      <thead>
        <tr>
          <th>Type</th>
          <th>Value</th>
          <th>Growth</th>
        </tr>
      </thead>
      <tbody>
        {investments.map((investment, index) => (
          <tr key={index}>
            <td>{investment.type}</td>
            <td>{investment.value}</td>
            <td>{investment.growth}</td>
          </tr>
        ))}
      </tbody>
    </table>
  </div>
);

export default Investments;
