// ChatBot.jsx
import React, { useState } from 'react';
import './index.css'; // Ensure this file is properly linked

const ChatBot = () => {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");

  const handleSend = (e) => {
    e.preventDefault();
    if (input.trim()) {
      const newMessage = {
        text: input,
        sender: "user",
      };
      setMessages((prevMessages) => [...prevMessages, newMessage]);
      setInput("");

      // Simulate a bot response after 1 second
      setTimeout(() => {
        const botResponse = {
          text: `You said: ${input}`, // Replace with actual bot logic
          sender: "bot",
        };
        setMessages((prevMessages) => [...prevMessages, botResponse]);
      }, 1000);
    }
  };

  return (
    <div className="chatbot-container">
      <div className="chatbot-header">
        {/* <h2>Chat with FinAI Assistant</h2> */}
      </div>
      <div className="chatbot-messages">
        {messages.map((message, index) => (
          <div key={index} className={`message ${message.sender}`}>
            {message.text}
          </div>
        ))}
      </div>
      <form onSubmit={handleSend} className="chatbot-input-form">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Type a message..."
          required
          className="chatbot-input"
        />
        <button type="submit" className="chatbot-send-button">Send</button>
      </form>
    </div>
  );
};

export default ChatBot;
