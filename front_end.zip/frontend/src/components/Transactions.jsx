import React from 'react';
import './index.css'; // Optional for styling

export default function Transactions() {
  const recentTransactions = [
    { name: "Grocery Store", category: "Food & Dining", amount: -85.43 },
    { name: "Electric Company", category: "Bills & Utilities", amount: -120.00 },
    { name: "Paycheck", category: "Income", amount: 2500.00 },
  ];

  return (
    <div className="transactions-page">
      <h1>Transactions</h1>
      <div className="transactions-list">
        {recentTransactions.map((transaction, index) => (
          <div key={index} className="transaction-item">
            <div className="transaction-info">
              <p className="transaction-name">{transaction.name}</p>
              <p className="transaction-category">{transaction.category}</p>
            </div>
            <span className={`transaction-amount ${transaction.amount > 0 ? "positive" : "negative"}`}>
              {transaction.amount > 0 ? "+" : ""}{transaction.amount.toFixed(2)}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
