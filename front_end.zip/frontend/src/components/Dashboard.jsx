import React, { useState } from 'react';
import { Bell, User } from 'lucide-react';
import './PersonalFinanceDashboard.css';

// Define your data arrays here
const accountStats = [
  { label: "Total Balance", value: "$12,345.67" },
  { label: "Income This Month", value: "$4,567.89" },
  { label: "Expenses This Month", value: "$3,210.45" },
];

const budgetCategories = [
  { name: "Groceries", percentage: 75 },
  { name: "Entertainment", percentage: 40 },
  { name: "Transportation", percentage: 90 },
];

const savingsGoals = [
  { name: "Vacation Fund", current: 2000, target: 5000 },
  { name: "Emergency Fund", current: 5000, target: 10000 },
];

const recentTransactions = [
  { name: "Grocery Store", category: "Food & Dining", amount: -85.43 },
  { name: "Electric Company", category: "Bills & Utilities", amount: -120.00 },
  { name: "Paycheck", category: "Income", amount: 2500.00 },
];

const aiInsights = [
  { title: "Savings Opportunity", description: "You could save $50 by reducing your entertainment spending by 10% this month." },
  { title: "Debt Reduction Strategy", description: "Consider applying the Avalanche Method to pay off your credit card debt faster and save on interest." },
  { title: "Investment Suggestion", description: "Based on your risk profile, consider diversifying your portfolio by adding 5% allocation to international stocks." },
];

const Dashboard = () => {
  const [showProfileDropdown, setShowProfileDropdown] = useState(false);
  const [showNotificationDropdown, setShowNotificationDropdown] = useState(false);

  const handleProfileClick = () => {
    setShowProfileDropdown((prev) => !prev);
    setShowNotificationDropdown(false); // Close notifications if open
  };

  const handleNotificationClick = () => {
    setShowNotificationDropdown((prev) => !prev);
    setShowProfileDropdown(false); // Close profile if open
  };

  const closeDropdowns = () => {
    setShowProfileDropdown(false);
    setShowNotificationDropdown(false);
  };

  return (
    <div className="main-content">
      <main className="main-content">
        <header className="header">
          <h1 className="page-title">Personal Finance Dashboard</h1>
          <div className="user-actions">
            {/* Notification Button */}
            <button className="notification-btn" onClick={handleNotificationClick}>
              <Bell className="notification-icon" />
            </button>
            {/* User Profile Icon */}
            <div className="user-avatar" onClick={handleProfileClick}>
              <User className="user-icon" />
              <div className={`profile-dropdown ${showProfileDropdown ? '' : 'hidden'}`} onMouseLeave={closeDropdowns}>
                <h3>User Details</h3>
                <p>Name: John Doe</p>
                <p>Email: johndoe@example.com</p>
                <p><a href="/settings">Account Settings</a></p>
                <p><a href="/logout">Logout</a></p>
              </div>
            </div>
            {/* Notification Dropdown */}
            <div className={`notification-dropdown ${showNotificationDropdown ? '' : 'hidden'}`} onMouseLeave={closeDropdowns}>
              <h3>Notifications</h3>
              <p>No new notifications</p>
              <p>Transaction alert for Electric Company</p>
              <p>Your paycheck has been deposited</p>
              <p>Upcoming bill due for Water Company</p>
            </div>
          </div>
        </header>

        <div className="dashboard-grid">
          {/* AI Insights */}
          <div className="card ai-insights">
            <h2 className="card-title">AI Insights & Recommendations</h2>
            <div className="insights-list">
              {aiInsights.map((insight, index) => (
                <div key={index} className="insight-item">
                  <h3 className="insight-title">{insight.title}</h3>
                  <p className="insight-description">{insight.description}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Account Overview */}
          <div className="card account-overview">
            <h2 className="card-title">Account Overview</h2>
            <div className="account-stats">
              {accountStats.map((stat, index) => (
                <div key={index} className="stat-item">
                  <p className="stat-label">{stat.label}</p>
                  <p className="stat-value">{stat.value}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Spending Insights */}
          <div className="card spending-insights">
            <h2 className="card-title">Spending Insights</h2>
            <p className="card-subtitle">Your spending patterns this month</p>
            <div className="chart-placeholder">
              <p>Chart Placeholder</p>
            </div>
          </div>

          {/* Budget Progress */}
          <div className="card budget-progress">
            <h2 className="card-title">Budget Progress</h2>
            <div className="progress-items">
              {budgetCategories.map((category) => (
                <div key={category.name} className="progress-item">
                  <div className="progress-header">
                    <span>{category.name}</span>
                    <span>{category.percentage}%</span>
                  </div>
                  <div className="progress-bar">
                    <div className="progress-fill" style={{ width: `${category.percentage}%` }}></div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Savings Goals */}
          <div className="card savings-goals">
            <h2 className="card-title">Savings Goals</h2>
            <div className="goals-list">
              {savingsGoals.map((goal) => (
                <div key={goal.name} className="goal-item">
                  <div className="goal-header">
                    <span>{goal.name}</span>
                    <span>${goal.current} / ${goal.target}</span>
                  </div>
                  <div className="progress-bar">
                    <div
                      className="progress-fill"
                      style={{ width: `${(goal.current / goal.target) * 100}%` }}
                    ></div>
                  </div>
                </div>
              ))}
              <button className="btn btn-success">Add New Goal</button>
            </div>
          </div>

          {/* Recent Transactions */}
          <div className="card recent-transactions">
            <h2 className="card-title">Recent Transactions</h2>
            <div className="transactions-list">
              {recentTransactions.map((transaction, index) => (
                <div key={index} className="transaction-item">
                  <div className="transaction-info">
                    <p className="transaction-name">{transaction.name}</p>
                    <p className="transaction-category">{transaction.category}</p>
                  </div>
                  <span className={`transaction-amount ${transaction.amount > 0 ? "positive" : "negative"}`}>
                    {transaction.amount > 0 ? "+" : ""}{transaction.amount.toFixed(2)}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Dashboard;
