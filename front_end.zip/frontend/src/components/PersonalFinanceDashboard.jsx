import React, { useState } from 'react';
import { DollarSign, Home, Wallet, Briefcase, Award, MessageCircle } from 'lucide-react'; // Ensure to import icons
import Dashboard from './Dashboard';
import Transactions from './Transactions';
import Investments from './Investments';
import Achievements from './Achievements';
import ChatBot from './ChatBot'; // Import the ChatBot component
import './PersonalFinanceDashboard.css';

const PersonalFinanceDashboard = () => {
  const [activeNavItem, setActiveNavItem] = useState('Dashboard');

  const navItems = [
    { icon: Home, label: 'Dashboard' },
    { icon: Wallet, label: 'Transactions' },
    { icon: Briefcase, label: 'Investments' },
    { icon: Award, label: 'Achievements' },
    { icon: MessageCircle, label: 'Chatbot' }, // Include Chatbot option
  ];

  const renderContent = () => {
    switch (activeNavItem) {
      case 'Dashboard':
        return <Dashboard />;
      case 'Transactions':
        return <Transactions />;
      case 'Investments':
        return <Investments />;
      case 'Achievements':  
        return <Achievements />;
      case 'Chatbot':
        return <ChatBot />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="dashboard">
      {/* Sidebar */}
      <aside className="sidebar">
        <div className="logo">
          <DollarSign className="logo-icon" />
          <span className="logo-text">FinAI Assistant</span>
        </div>
        <nav className="nav">
          {navItems.map(({ icon: Icon, label }) => (
            <button
              key={label}
              className={`nav-item ${activeNavItem === label ? 'active' : ''}`}
              onClick={() => setActiveNavItem(label)}
            >
              <Icon className="nav-icon" />
              {label}
            </button>
          ))}
        </nav>
      </aside>
  
      {/* Main content */}
      <main className="main-content">
        {renderContent()}
      </main>
    </div>
  );
};

export default PersonalFinanceDashboard;
