import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PersonalFinanceDashboard from './components/PersonalFinanceDashboard';
import Transactions from './components/Transactions';
import Achievements from './components/Achievements';
import Investments from './components/Investments';
import ChatBot from './components/ChatBot';
import { AuthProvider } from './components/AuthProvider'; // Import AuthProvider for managing auth
import Login from './components/LoginPage';         // Login page component
import SignUp from './components/SignUpPage';       // Signup page component
import ProtectedRoute from './components/ProtectedRoute'; // ProtectedRoute for authenticated access

export default function App() {
  return (
    <Router>
      <AuthProvider> {/* Wrap your app with AuthProvider to handle authentication */}
        <Routes>
          {/* Public Routes */}
          <Route path="/" element={<Login />} />    {/* Login Page */}
          <Route path="/signup" element={<SignUp />} />  {/* Signup Page */}

          {/* Protected Routes */}
          <Route
            path="/dashboard"
            element={
              <ProtectedRoute>
                <PersonalFinanceDashboard />  
              </ProtectedRoute>
            }
          />
          <Route
            path="/transactions"
            element={
              <ProtectedRoute>
                <Transactions />
              </ProtectedRoute>
            }
          />
          <Route
            path="/achievements"
            element={
              <ProtectedRoute>
                <Achievements />
              </ProtectedRoute>
            }
          />
          <Route
            path="/investments"
            element={
              <ProtectedRoute>
                <Investments />
              </ProtectedRoute>
            }
          />
          <Route
            path="/chatbot"
            element={
              <ProtectedRoute>
                <ChatBot />
              </ProtectedRoute>
            }
          />
        </Routes>
      </AuthProvider>
    </Router>
  );
}
